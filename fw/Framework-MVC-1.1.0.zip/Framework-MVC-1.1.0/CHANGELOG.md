CHANGELOG
=========

* 1.1.0 (2013-10-28)

 * Formatage du code selon les standards [php-fig] (http://www.php-fig.org/psr/psr-2/)
 * Gestion des sessions
 * Possibilité pour un contrôleur de générer une vue spécifique
 * Possibilité pour un contrôleur de rediriger vers une action d'un autre contrôleur

* 1.0.0 (2013-10-15)

 * Version initiale


